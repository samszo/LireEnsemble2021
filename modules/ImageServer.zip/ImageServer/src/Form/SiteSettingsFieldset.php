<?php declare(strict_types=1);

namespace ImageServer\Form;

class SiteSettingsFieldset extends SettingsFieldset
{
}
