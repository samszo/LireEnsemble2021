{"vocabulary" : {
    "o:namespace_uri" : "https://polemika.univ-paris8.fr/onto/polemika#",
    "o:prefix" : "plmk",
    "o:label" : "Polemika", 
    "o:comment" : "Vocabulaire pour le projet de recherche Polemika"
},
"strategy":"file",
"file" : "polemika.ttl",
"format" : "turtle"
}