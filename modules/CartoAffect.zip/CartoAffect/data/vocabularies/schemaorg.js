{"vocabulary" : {
    "o:namespace_uri" : "http://schema.org/",
    "o:prefix" : "schema",
    "o:label" : "schema.org", 
    "o:comment" : "Schema.org is a collaborative, community activity with a mission to create, maintain, and promote schemas for structured data on the Internet, on web pages, in email messages, and beyond."
},
"strategy":"file",
"file" : "schemaorg.ttl",
"format" : "turtle"
}