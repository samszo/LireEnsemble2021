{"vocabulary" : {
    "o:namespace_uri" : "http://www.w3.org/2004/02/skos/core#",
    "o:prefix" : "skos",
    "o:label" : "SKOS", 
    "o:comment" : "Simple Knowledge Organization System"
},
"strategy":"file",
"file" : "skos.ttl",
"format" : "turtle"
}