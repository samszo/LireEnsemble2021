<?php
namespace CartoAffect\View\Helper;

use Laminas\View\Helper\AbstractHelper;
use Omeka\Api\Exception;
use Omeka\Stdlib\ErrorStore;

class EntityRelationViewHelper extends AbstractHelper
{
    protected $api;
    protected $conn;
    protected $default_rs_i = 'Position des entités'; // Resource template
    protected $default_rs_c = 'Carte des entités'; // Resource template
    protected $default_term_class = 'geom:GeometryCollection'; // Class - Collection de géométries
    protected $dft_class_item = 'geom:Geometry';

    public function __construct($api, $conn)
    {
        $this->api = $api;
        $this->conn = $conn;
    }

    /**
     * Gestion des diagrammes entités relation
     *
     * @param string $action nom de l'action
     * @param array $params paramètre de l'action
     * @return array
     */
    public function __invoke($action = "", $params = [])
    {
        if (!$action || !$params) return [];

        switch ($action) {
            case 'updatePosition':
                $result = $this->updatePosition($params);
                break;
            case 'addPosition':
                $result = $this->addPosition($params);
                break;
            case 'listItem':
                $result = $this->listItem($params);
                break;
            case 'valeurPro':
                $result = $this->valeurPro($params);
                break;
            case 'getProItem':
                $result = $this->getProItem($params);
                break;
            case 'getTabEntite':
                $result = $this->getTabEntite($params);
                break;
        }

        return $result;

    }

    /**
     * mis à jour des positions de l'entité
     *
     * @param array $params paramètre de l'action
     * @return array
     */
    function updatePosition($params)
    {
        $errorStore = new ErrorStore;

        $result = [];

        foreach ($params as $value) {
            if (is_array($value) && count($value) > 2) {
                $resource = $this->api->read('items', $value[0])->getContent();
                $currentData = json_decode(json_encode($resource), true);
                //construstion des valeurs
                $currentData['geom:coordX'][0]['@value'] = $value[1];
                $currentData['geom:coordY'][0]['@value'] = $value[2];

                // mise a jour x & y de id item
                try {
                    $this->api->update('items', $value[0], $currentData, []
                        , ['isPartial' => true, 'continueOnError' => true, 'collectionAction' => 'replace']);
                    $result['success'][] = json_encode($currentData);
                } catch (Exception\ValidationException $e) {
                    $errorStore->mergeErrors($e->getErrorStore(), json_encode($currentData));
                }
            }
        }

        return $result;
    }

    /**
     * creer des positions de l'entité
     * @param array $params paramètre de l'action
     * @return array
     */
    function addPosition($params)
    {
        $errorStore = new ErrorStore;

        $result = [];
        $arr_id_items = [];
        $pos_x = 100;
        $pos_y = 100;
        $i = 1;

        $name_carte = $params['name_carte'];
        $dft_collection = $params['default_collection'];

        // creer contenues
        foreach ($params['chk_class'] as $obj_class) {
            $name_class = $obj_class['label'];
            $term_class = $obj_class['term'];

            $oItem = [];
            $oItem['o:title'] = "$name_carte" . "_" . $name_class;
            $oItem['dcterms:title'] = "$name_carte" . "_" . $name_class;
            $oItem['geom:coordX'] = (string)($pos_x * $i);
            $oItem['geom:coordY'] = (string)($pos_y * $i);
            $oItem['schema:structuralClass'] = $term_class;

            $rt = $this->api->search('resource_templates', ['label' => $this->default_rs_i])->getContent()[0];
            $rc = $this->api->search('resource_classes', ['term' => $this->dft_class_item])->getContent()[0];

            $oItem = $this->setData($oItem, $rt, $rc);

            try {
                // add
                $result_add = $this->api->create('items', $oItem, [], ['continueOnError' => true])->getContent();
                $arr_id_items[] = $result_add->id();
            } catch (Exception\ValidationException $e) {
                $errorStore->mergeErrors($e->getErrorStore(), json_encode($oItem));
            }

            $i++;
        }

        // creer carte
        $oItem = [];
        foreach ($arr_id_items as $key => $id_item) {
            $oItem['geom:geometry'][$key]['value'] = $id_item;
        }
        $oItem['o:title'] = "$name_carte";
        $oItem['dcterms:title'] = "$name_carte";
        $oItem['dcterms:description'] = "$name_carte";

        $rt = $this->api->search('resource_templates', ['label' => $this->default_rs_c])->getContent()[0];
        $rc = $this->api->search('resource_classes', ['term' => $this->default_term_class])->getContent()[0];

        $oItem = $this->setData($oItem, $rt, $rc);
        $oItem['o:item_set'][0]['o:id'] = $dft_collection;

        try {
            // add
            $result_c = $this->api->create('items', $oItem, [], ['continueOnError' => true])->getContent();
            $result['success']['id_carte'] = $result_c->id();
        } catch (Exception\ValidationException $e) {
            $errorStore->mergeErrors($e->getErrorStore(), json_encode($oItem));
        }

        return $result;
    }

    /** Construction des data pour l'API
     *
     * @param array $data
     * @param object $rt
     * @param object $rc
     * @return  array
     */
    protected function setData($data, $rt, $rc)
    {
        $oItem = [];
        $oItem['o:resource_class'] = ['o:id' => $rc->id()];
        $oItem['o:resource_template'] = ['o:id' => $rt->id()];
        foreach ($rt->resourceTemplateProperties() as $p) {
            $oP = $p->property();
            if (isset($data[$oP->term()])) {
                $val = $data[$oP->term()];
                $oItem = $this->setValeur($val, $oP, $oItem);
            }
        }
        return $oItem;

    }

    /** Construction de la valeur
     *
     * @param array $val
     * @param object $oP
     * @param array $oItem
     * @return  array
     */
    protected function setValeur($val, $oP, $oItem)
    {
        if (is_string($val)) $val = [$val];
        foreach ($val as $v) {
            $valueObject = [];
            if (!is_string($v) && $v['value']) {
                $valueObject['value_resource_id'] = $v['value'];
                $valueObject['property_id'] = $oP->id();
                $valueObject['type'] = 'resource';
            } else {
                $valueObject['@value'] = $v;
                $valueObject['type'] = 'literal';
                $valueObject['property_id'] = $oP->id();
            }
            $oItem[$oP->term()][] = $valueObject;
        }
        return $oItem;
    }

    /**
     * liste de items de resource class
     * @param array $params paramètre de l'action
     * @return array
     */
    function listItem($params) {
        $result = [];
        $arr_item_id = [];

        $items = $this->api->search('items', [
                                                'resource_template_id' => $params,
                                            ])->getContent();
        $i = 0;
        foreach ($items as $item) {
            $arr_item_id[$i]['id'] = $item->id();
            $arr_item_id[$i]['title'] = $item->title();
            $i++;
        }

        // sort array
        usort($arr_item_id, function($a, $b) {
            return $a['title'] <=> $b['title'];
        });

        $result['success'][] = json_encode($arr_item_id);
        return $result;
    }

    /**
     * liste de items de tabs entite
     * @param array $params paramètre de l'action
     * @return array
     */
    function getTabEntite($params) {
        $result = [];

        $result['success'][] = json_encode($params);
        return $result;
    }

    /**
     * liste de valeur de proprietes
     * @param array $params paramètre de l'action
     * @return array
     */
    function valeurPro($params)
    {
        $id_pro = $params[1];
        $id_rt = $params[0];
        $result = [];
        $arr_v_p = [];

        if (isset($_SESSION['pro_value'][$id_rt][$id_pro])) {
            $arr_v_p = $_SESSION['pro_value'][$id_rt][$id_pro];

            // sort array
            usort($arr_v_p, function ($a, $b) {
                return $a['v_p'] <=> $b['v_p'];
            });
        }

        $result['success'][] = json_encode($arr_v_p);
        return $result;
    }

    /**
     * prendre items de propriete
     *
     * @param array $var array de propriete et id de resource template
     * @return array
     */
    function getProItem($var) {
        $p = $var['p'];
        $id_rt = $var['id_rt'];
        $arr_v_p = [];
        $id_pro = $p->id();

        $param = array();
        $param['property'][0]['property']= $id_pro."";
        $param['property'][0]['type']='ex';
        $param['resource_template_id'] = $id_rt;
        $items = $this->api->search('items', $param)->getContent();

        foreach ($items as $item) {
            //récupère les valeurs
            $values = $item->value($p->term(), ['all' => true]);

            foreach ($values as $v) {
                $p_i = $v->property();

                if ($p_i->id() == $id_pro) {
                    $value_pro = $item->value($p_i->term())->asHtml();

                    // couper la chaine quand il y a un lien
                    if(strpos($value_pro, 'resource-link') !== false){ // a été trouvée
                        $pos_begin = strpos($value_pro, '<span');
                        $pos_end = strpos($value_pro, '</span>');
                        $str_cut = substr($value_pro, $pos_begin, $pos_end);
                        $value_pro = $str_cut;
                    }

                    $arr_v_p["$value_pro"]['id'] = $item->id();
                    $arr_v_p["$value_pro"]['v_p'] = $value_pro;

                    $_SESSION['pro_value'][$id_rt][$id_pro]["$value_pro"]['id'] = $arr_v_p["$value_pro"]['id'];
                    $_SESSION['pro_value'][$id_rt][$id_pro]["$value_pro"]['v_p'] = $arr_v_p["$value_pro"]['v_p'];

                    break;
                }
            }
        }

        return $arr_v_p;
    }

}
