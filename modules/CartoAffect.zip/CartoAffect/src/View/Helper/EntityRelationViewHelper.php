<?php
namespace CartoAffect\View\Helper;

use Laminas\View\Helper\AbstractHelper;
use Omeka\Api\Exception;
use Omeka\Stdlib\ErrorStore;

class EntityRelationViewHelper extends AbstractHelper
{
    protected $api;
    protected $conn;
    protected $default_rs_i = 'Position des entités'; // Resource template
    protected $default_rs_c = 'Carte des entités'; // Resource template
    protected $default_term_class = 'epe:cllection'; // Class
    protected $default_vocabulary_id = 7; // Tibor & BnF

    public function __construct($api, $conn)
    {
        $this->api = $api;
        $this->conn = $conn;
    }

    /**
     * Gestion des diagrammes entités relation
     *
     * @param string $action nom de l'action
     * @param array $params paramètre de l'action
     * @return array
     */
    public function __invoke($action = "", $params = [])
    {
        if (!$action || !$params) return [];

        switch ($action) {
            case 'updatePosition':
                $result = $this->updatePosition($params);
                break;
            case 'addPosition':
                $result = $this->addPosition($params);
                break;
            case 'listItem':
                $result = $this->listItem($params);
                break;
        }

        return $result;

    }

    /**
     * mis à jour des positions de l'entité
     *
     * @param array $params paramètre de l'action
     * @return array
     */
    function updatePosition($params)
    {
        $errorStore = new ErrorStore;

        $result = [];
        foreach ($params as $key => $value) {
            if (is_array($value) && count($value) > 2) {
                $resource = $this->api->read('items', $value[0])->getContent();
                $currentData = json_decode(json_encode($resource), true);
                //construstion des valeurs
                $currentData['geom:coordX'][0]['@value'] = $value[1];
                $currentData['geom:coordY'][0]['@value'] = $value[2];

                // mise a jour x & y de id item
                try {
                    $this->api->update('items', $value[0], $currentData, []
                        , ['isPartial' => true, 'continueOnError' => true, 'collectionAction' => 'replace']);
                    $result['success'][] = json_encode($currentData);
                } catch (Exception\ValidationException $e) {
                    $errorStore->mergeErrors($e->getErrorStore(), json_encode($currentData));
                }
            }
        }

        return $result;
    }

    /**
     * creer des positions de l'entité
     * @param array $params paramètre de l'action
     * @return array
     */
    function addPosition($params)
    {
        $errorStore = new ErrorStore;

        $result = [];
        $arr_id_items = [];
        $pos_x = 100;
        $pos_y = 100;
        $i = 1;

        $name_carte = $params['name_carte'];
        $dft_collection = $params['default_collection'];

        // creer contenues
        foreach ($params['chk_class'] as $id_class => $name_class) {
            $oItem = [];
            $oItem['o:title'] = "$name_carte" . "_" . $name_class;
            $oItem['dcterms:title'] = "$name_carte" . "_" . $name_class;
            $oItem['geom:coordX'] = (string)($pos_x * $i);
            $oItem['geom:coordY'] = (string)($pos_y * $i);

            $rt = $this->api->search('resource_templates', ['label' => $this->default_rs_i])->getContent()[0];
            $rc = $this->api->search('resource_classes', ['id' => $id_class])->getContent()[0];

            $oItem = $this->setData($oItem, $rt, $rc);

            try {
                // add
                $result_add = $this->api->create('items', $oItem, [], ['continueOnError' => true])->getContent();
                $arr_id_items[] = $result_add->id();
            } catch (Exception\ValidationException $e) {
                $errorStore->mergeErrors($e->getErrorStore(), json_encode($oItem));
            }

            $i++;
        }

        // creer carte
        $oItem = [];
        foreach ($arr_id_items as $key => $id_item) {
            $oItem['geom:geometry'][$key]['value'] = $id_item;
        }
        $oItem['o:title'] = "$name_carte";
        $oItem['dcterms:title'] = "$name_carte";
        $oItem['dcterms:description'] = "$name_carte";

        $rt = $this->api->search('resource_templates', ['label' => $this->default_rs_c])->getContent()[0];
        $rc = $this->api->search('resource_classes', ['term' => $this->default_term_class, 'vocabulary_id' => $this->default_vocabulary_id])->getContent()[0];

        $oItem = $this->setData($oItem, $rt, $rc);
        $oItem['o:item_set'][0]['o:id'] = $dft_collection;

        try {
            // add
            $result_c = $this->api->create('items', $oItem, [], ['continueOnError' => true])->getContent();
            $result['success']['id_carte'] = $result_c->id();
        } catch (Exception\ValidationException $e) {
            $errorStore->mergeErrors($e->getErrorStore(), json_encode($oItem));
        }

        return $result;
    }

    /** Construction des data pour l'API
     *
     * @param array $data
     * @param object $rt
     * @param object $rc
     * @return  array
     */
    protected function setData($data, $rt, $rc)
    {
        $oItem = [];
        $oItem['o:resource_class'] = ['o:id' => $rc->id()];
        $oItem['o:resource_template'] = ['o:id' => $rt->id()];
        foreach ($rt->resourceTemplateProperties() as $p) {
            $oP = $p->property();
            if (isset($data[$oP->term()])) {
                $val = $data[$oP->term()];
                $oItem = $this->setValeur($val, $oP, $oItem);
            }
        }
        return $oItem;

    }

    /** Construction de la valeur
     *
     * @param array $val
     * @param object $oP
     * @param array $oItem
     * @return  array
     */
    protected function setValeur($val, $oP, $oItem)
    {
        if (is_string($val)) $val = [$val];
        foreach ($val as $v) {
            $valueObject = [];
            if (!is_string($v) && $v['value']) {
                $valueObject['value_resource_id'] = $v['value'];
                $valueObject['property_id'] = $oP->id();
                $valueObject['type'] = 'resource';
            } else {
                $valueObject['@value'] = $v;
                $valueObject['type'] = 'literal';
                $valueObject['property_id'] = $oP->id();
            }
            $oItem[$oP->term()][] = $valueObject;
        }
        return $oItem;
    }

    /**
     * liste de items de resource class
     * @param array $params paramètre de l'action
     * @return array
     */
    function listItem($params) {
        $result = [];
        $arr_item_id = [];

        $query_rs = [
            'id' => $params,
        ];
        $resource_templates = $this->api->search('resource_templates', $query_rs, ['limit' => 0])->getContent();

        foreach ($resource_templates as $key => $rt) {
            $pros = $rt->resourceClass();

            $items = $this->api->search('items')->getContent();
            $i = 0;
            foreach ($items as $item) {
                if ($pros->id() == $item->resourceClass()->id()) {
                    $arr_item_id[$i]['id'] = $item->id();
                    $arr_item_id[$i]['title'] = $item->title();
                    $i++;
                }
            }

            $result['success'][] = json_encode($arr_item_id);
            return $result;
        }
    }

}
