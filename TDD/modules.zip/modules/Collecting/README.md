# Collecting

Add collecting forms to your Omeka S sites.

See the [Omeka S user manual](http://omeka.org/s/docs/user-manual/modules/collecting/) for user documentation.

## Installation

See general end user documentation for [Installing a module](http://omeka.org/s/docs/user-manual/modules/#installing-modules)
