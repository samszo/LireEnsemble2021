DROP TABLE IF EXISTS ebook_creation;
